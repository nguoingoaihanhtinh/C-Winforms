﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StudentDBDataSet1.SINHVIEN' table. You can move, or remove it, as needed.
        Me.SINHVIENTableAdapter1.Fill(Me.StudentDBDataSet1.SINHVIEN)
        'TODO: This line of code loads data into the 'StudentDBDataSet.SINHVIEN' table. You can move, or remove it, as needed.
        Me.SINHVIENTableAdapter.Fill(Me.StudentDBDataSet.SINHVIEN)

    End Sub

    Private Sub SINHVIENBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles SINHVIENBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.SINHVIENBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentDBDataSet)

    End Sub
End Class
