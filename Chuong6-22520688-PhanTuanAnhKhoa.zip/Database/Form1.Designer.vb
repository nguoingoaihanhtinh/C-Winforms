﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim MaSoLabel As System.Windows.Forms.Label
        Dim HoTenLabel As System.Windows.Forms.Label
        Dim NgaySinhLabel As System.Windows.Forms.Label
        Dim GioiTinhLabel As System.Windows.Forms.Label
        Dim DiaChiLabel As System.Windows.Forms.Label
        Dim SDTLabel As System.Windows.Forms.Label
        Me.StudentDBDataSet = New Database.StudentDBDataSet()
        Me.SINHVIENBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SINHVIENTableAdapter = New Database.StudentDBDataSetTableAdapters.SINHVIENTableAdapter()
        Me.TableAdapterManager = New Database.StudentDBDataSetTableAdapters.TableAdapterManager()
        Me.SINHVIENBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.SINHVIENBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.MaSoTextBox = New System.Windows.Forms.TextBox()
        Me.HoTenTextBox = New System.Windows.Forms.TextBox()
        Me.NgaySinhDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.GioiTinhTextBox = New System.Windows.Forms.TextBox()
        Me.DiaChiTextBox = New System.Windows.Forms.TextBox()
        Me.SDTTextBox = New System.Windows.Forms.TextBox()
        Me.StudentDBDataSet1 = New Database.StudentDBDataSet1()
        Me.SINHVIENBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.SINHVIENTableAdapter1 = New Database.StudentDBDataSet1TableAdapters.SINHVIENTableAdapter()
        Me.TableAdapterManager1 = New Database.StudentDBDataSet1TableAdapters.TableAdapterManager()
        Me.SINHVIENDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        MaSoLabel = New System.Windows.Forms.Label()
        HoTenLabel = New System.Windows.Forms.Label()
        NgaySinhLabel = New System.Windows.Forms.Label()
        GioiTinhLabel = New System.Windows.Forms.Label()
        DiaChiLabel = New System.Windows.Forms.Label()
        SDTLabel = New System.Windows.Forms.Label()
        CType(Me.StudentDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SINHVIENBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SINHVIENBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SINHVIENBindingNavigator.SuspendLayout()
        CType(Me.StudentDBDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SINHVIENBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SINHVIENDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StudentDBDataSet
        '
        Me.StudentDBDataSet.DataSetName = "StudentDBDataSet"
        Me.StudentDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SINHVIENBindingSource
        '
        Me.SINHVIENBindingSource.DataMember = "SINHVIEN"
        Me.SINHVIENBindingSource.DataSource = Me.StudentDBDataSet
        '
        'SINHVIENTableAdapter
        '
        Me.SINHVIENTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.SINHVIENTableAdapter = Me.SINHVIENTableAdapter
        Me.TableAdapterManager.UpdateOrder = Database.StudentDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'SINHVIENBindingNavigator
        '
        Me.SINHVIENBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.SINHVIENBindingNavigator.BindingSource = Me.SINHVIENBindingSource
        Me.SINHVIENBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.SINHVIENBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.SINHVIENBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.SINHVIENBindingNavigatorSaveItem})
        Me.SINHVIENBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.SINHVIENBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.SINHVIENBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.SINHVIENBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.SINHVIENBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.SINHVIENBindingNavigator.Name = "SINHVIENBindingNavigator"
        Me.SINHVIENBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.SINHVIENBindingNavigator.Size = New System.Drawing.Size(701, 25)
        Me.SINHVIENBindingNavigator.TabIndex = 0
        Me.SINHVIENBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 15)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'SINHVIENBindingNavigatorSaveItem
        '
        Me.SINHVIENBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SINHVIENBindingNavigatorSaveItem.Image = CType(resources.GetObject("SINHVIENBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.SINHVIENBindingNavigatorSaveItem.Name = "SINHVIENBindingNavigatorSaveItem"
        Me.SINHVIENBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 23)
        Me.SINHVIENBindingNavigatorSaveItem.Text = "Save Data"
        '
        'MaSoLabel
        '
        MaSoLabel.AutoSize = True
        MaSoLabel.Location = New System.Drawing.Point(36, 50)
        MaSoLabel.Name = "MaSoLabel"
        MaSoLabel.Size = New System.Drawing.Size(41, 13)
        MaSoLabel.TabIndex = 2
        MaSoLabel.Text = "Ma So:"
        '
        'MaSoTextBox
        '
        Me.MaSoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SINHVIENBindingSource, "MaSo", True))
        Me.MaSoTextBox.Location = New System.Drawing.Point(83, 47)
        Me.MaSoTextBox.Name = "MaSoTextBox"
        Me.MaSoTextBox.Size = New System.Drawing.Size(100, 20)
        Me.MaSoTextBox.TabIndex = 3
        '
        'HoTenLabel
        '
        HoTenLabel.AutoSize = True
        HoTenLabel.Location = New System.Drawing.Point(31, 76)
        HoTenLabel.Name = "HoTenLabel"
        HoTenLabel.Size = New System.Drawing.Size(46, 13)
        HoTenLabel.TabIndex = 4
        HoTenLabel.Text = "Ho Ten:"
        '
        'HoTenTextBox
        '
        Me.HoTenTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SINHVIENBindingSource, "HoTen", True))
        Me.HoTenTextBox.Location = New System.Drawing.Point(83, 73)
        Me.HoTenTextBox.Name = "HoTenTextBox"
        Me.HoTenTextBox.Size = New System.Drawing.Size(200, 20)
        Me.HoTenTextBox.TabIndex = 5
        '
        'NgaySinhLabel
        '
        NgaySinhLabel.AutoSize = True
        NgaySinhLabel.Location = New System.Drawing.Point(18, 103)
        NgaySinhLabel.Name = "NgaySinhLabel"
        NgaySinhLabel.Size = New System.Drawing.Size(59, 13)
        NgaySinhLabel.TabIndex = 6
        NgaySinhLabel.Text = "Ngay Sinh:"
        '
        'NgaySinhDateTimePicker
        '
        Me.NgaySinhDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.SINHVIENBindingSource, "NgaySinh", True))
        Me.NgaySinhDateTimePicker.Location = New System.Drawing.Point(83, 99)
        Me.NgaySinhDateTimePicker.Name = "NgaySinhDateTimePicker"
        Me.NgaySinhDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.NgaySinhDateTimePicker.TabIndex = 7
        '
        'GioiTinhLabel
        '
        GioiTinhLabel.AutoSize = True
        GioiTinhLabel.Location = New System.Drawing.Point(447, 50)
        GioiTinhLabel.Name = "GioiTinhLabel"
        GioiTinhLabel.Size = New System.Drawing.Size(52, 13)
        GioiTinhLabel.TabIndex = 8
        GioiTinhLabel.Text = "Gioi Tinh:"
        '
        'GioiTinhTextBox
        '
        Me.GioiTinhTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SINHVIENBindingSource, "GioiTinh", True))
        Me.GioiTinhTextBox.Location = New System.Drawing.Point(505, 43)
        Me.GioiTinhTextBox.Name = "GioiTinhTextBox"
        Me.GioiTinhTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GioiTinhTextBox.TabIndex = 9
        '
        'DiaChiLabel
        '
        DiaChiLabel.AutoSize = True
        DiaChiLabel.Location = New System.Drawing.Point(454, 73)
        DiaChiLabel.Name = "DiaChiLabel"
        DiaChiLabel.Size = New System.Drawing.Size(44, 13)
        DiaChiLabel.TabIndex = 10
        DiaChiLabel.Text = "Dia Chi:"
        '
        'DiaChiTextBox
        '
        Me.DiaChiTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SINHVIENBindingSource, "DiaChi", True))
        Me.DiaChiTextBox.Location = New System.Drawing.Point(504, 69)
        Me.DiaChiTextBox.Name = "DiaChiTextBox"
        Me.DiaChiTextBox.Size = New System.Drawing.Size(170, 20)
        Me.DiaChiTextBox.TabIndex = 11
        '
        'SDTLabel
        '
        SDTLabel.AutoSize = True
        SDTLabel.Location = New System.Drawing.Point(466, 99)
        SDTLabel.Name = "SDTLabel"
        SDTLabel.Size = New System.Drawing.Size(32, 13)
        SDTLabel.TabIndex = 12
        SDTLabel.Text = "SDT:"
        '
        'SDTTextBox
        '
        Me.SDTTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SINHVIENBindingSource, "SDT", True))
        Me.SDTTextBox.Location = New System.Drawing.Point(504, 96)
        Me.SDTTextBox.Name = "SDTTextBox"
        Me.SDTTextBox.Size = New System.Drawing.Size(170, 20)
        Me.SDTTextBox.TabIndex = 13
        '
        'StudentDBDataSet1
        '
        Me.StudentDBDataSet1.DataSetName = "StudentDBDataSet1"
        Me.StudentDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SINHVIENBindingSource1
        '
        Me.SINHVIENBindingSource1.DataMember = "SINHVIEN"
        Me.SINHVIENBindingSource1.DataSource = Me.StudentDBDataSet1
        '
        'SINHVIENTableAdapter1
        '
        Me.SINHVIENTableAdapter1.ClearBeforeFill = True
        '
        'TableAdapterManager1
        '
        Me.TableAdapterManager1.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager1.SINHVIENTableAdapter = Me.SINHVIENTableAdapter1
        Me.TableAdapterManager1.UpdateOrder = Database.StudentDBDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'SINHVIENDataGridView
        '
        Me.SINHVIENDataGridView.AutoGenerateColumns = False
        Me.SINHVIENDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SINHVIENDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.SINHVIENDataGridView.DataSource = Me.SINHVIENBindingSource1
        Me.SINHVIENDataGridView.Location = New System.Drawing.Point(21, 163)
        Me.SINHVIENDataGridView.Name = "SINHVIENDataGridView"
        Me.SINHVIENDataGridView.Size = New System.Drawing.Size(653, 220)
        Me.SINHVIENDataGridView.TabIndex = 13
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "MaSo"
        Me.DataGridViewTextBoxColumn1.HeaderText = "MaSo"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "HoTen"
        Me.DataGridViewTextBoxColumn2.HeaderText = "HoTen"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "NgaySinh"
        Me.DataGridViewTextBoxColumn3.HeaderText = "NgaySinh"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "GioiTinh"
        Me.DataGridViewTextBoxColumn4.HeaderText = "GioiTinh"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "DiaChi"
        Me.DataGridViewTextBoxColumn5.HeaderText = "DiaChi"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "SDT"
        Me.DataGridViewTextBoxColumn6.HeaderText = "SDT"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(701, 475)
        Me.Controls.Add(Me.SINHVIENDataGridView)
        Me.Controls.Add(SDTLabel)
        Me.Controls.Add(Me.SDTTextBox)
        Me.Controls.Add(DiaChiLabel)
        Me.Controls.Add(Me.DiaChiTextBox)
        Me.Controls.Add(GioiTinhLabel)
        Me.Controls.Add(Me.GioiTinhTextBox)
        Me.Controls.Add(NgaySinhLabel)
        Me.Controls.Add(Me.NgaySinhDateTimePicker)
        Me.Controls.Add(HoTenLabel)
        Me.Controls.Add(Me.HoTenTextBox)
        Me.Controls.Add(MaSoLabel)
        Me.Controls.Add(Me.MaSoTextBox)
        Me.Controls.Add(Me.SINHVIENBindingNavigator)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.StudentDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SINHVIENBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SINHVIENBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SINHVIENBindingNavigator.ResumeLayout(False)
        Me.SINHVIENBindingNavigator.PerformLayout()
        CType(Me.StudentDBDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SINHVIENBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SINHVIENDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents StudentDBDataSet As StudentDBDataSet
    Friend WithEvents SINHVIENBindingSource As BindingSource
    Friend WithEvents SINHVIENTableAdapter As StudentDBDataSetTableAdapters.SINHVIENTableAdapter
    Friend WithEvents TableAdapterManager As StudentDBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents SINHVIENBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents SINHVIENBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents MaSoTextBox As TextBox
    Friend WithEvents HoTenTextBox As TextBox
    Friend WithEvents NgaySinhDateTimePicker As DateTimePicker
    Friend WithEvents GioiTinhTextBox As TextBox
    Friend WithEvents DiaChiTextBox As TextBox
    Friend WithEvents SDTTextBox As TextBox
    Friend WithEvents StudentDBDataSet1 As StudentDBDataSet1
    Friend WithEvents SINHVIENBindingSource1 As BindingSource
    Friend WithEvents SINHVIENTableAdapter1 As StudentDBDataSet1TableAdapters.SINHVIENTableAdapter
    Friend WithEvents TableAdapterManager1 As StudentDBDataSet1TableAdapters.TableAdapterManager
    Friend WithEvents SINHVIENDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
End Class
