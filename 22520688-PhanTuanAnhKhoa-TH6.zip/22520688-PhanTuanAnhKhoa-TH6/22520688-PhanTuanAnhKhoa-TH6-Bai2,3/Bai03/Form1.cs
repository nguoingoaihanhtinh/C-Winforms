

using System.Diagnostics;

namespace Bai03
{
    public partial class Form1 : Form
    {
        protected string curPath { get; set; }
        public Form1()
        {
            InitializeComponent();
            listView1.LargeImageList = imageList1;
            listView1.SmallImageList = imageList2;
            DriveInfo[] allDrives = DriveInfo.GetDrives();
            diskMenuItem.Text = allDrives[0].Name;
            curPath = allDrives[0].Name;
            for (int i = 0; i < allDrives.Length; i++)
            {
                diskMenuItem.Items.Add(allDrives[i].Name);
            }

            ShowDirectory();
            ShowFiles();
        }
        private void diskMenuItem_TextChanged(object sender, EventArgs e)
        {
            curPath = diskMenuItem.Text;
            ShowDirectory();
            ShowFiles();
            label1.Text = curPath;
           
        }
        private void iconToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.View = View.LargeIcon;
        }
        private void detailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.View = View.Details;
        }
        private void ShowDirectory() {
            listView1.Items.Clear();
            string[] directories = Directory.GetDirectories(curPath);
            foreach (string directory in directories)
            {
                DirectoryInfo dirInfo = new DirectoryInfo(directory);
                ListViewItem item = new ListViewItem(dirInfo.Name,0);
                item.SubItems.Add("<DIR>");
                item.SubItems.Add("");
                item.SubItems.Add(dirInfo.LastWriteTime.ToString());
                

                listView1.Items.Add(item);
            }

        }
        private void ShowFiles()
        {
                string[] files = Directory.GetFiles(curPath);

                foreach (string file in files)
                {
                    FileInfo fileInfo = new FileInfo(file);
                    ListViewItem item = new ListViewItem(fileInfo.Name,1);
                    string fileType = "File";
                    string fileExtension = fileInfo.Extension;
                    if (!string.IsNullOrEmpty(fileExtension))
                    {
                        fileType = fileExtension.Substring(1);
                    }
                    item.SubItems.Add(fileType);
                    double fileSizeKB = fileInfo.Length / 1024.0;  
                    item.SubItems.Add(fileSizeKB.ToString("N0")); 
                    item.SubItems.Add(fileInfo.LastWriteTime.ToString());
                    listView1.Items.Add(item);
                }
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left && listView1.SelectedItems.Count > 0)
            {
                curPath = Path.Combine(curPath, listView1.SelectedItems[0].Text);
                
                if (Directory.Exists(curPath))
                {
                    ShowDirectory();
                    ShowFiles();
                    label1.Text = curPath;
                }
                else if (File.Exists(curPath)) {
                    Process.Start("explorer.exe", curPath);
                    BackOneDir();
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            BackOneDir();
            ShowDirectory();
            ShowFiles();
            label1.Text = curPath;
        }
        private void BackOneDir()
        {
            DirectoryInfo parentDirectory = Directory.GetParent(curPath);

            if (parentDirectory != null)
            {
                curPath =  parentDirectory.FullName;
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 tmp = new Form2();
            tmp.StartPosition = FormStartPosition.Manual;
            int centerX = this.Location.X + (this.Width - tmp.Width) / 2;
            int centerY = this.Location.Y + (this.Height - tmp.Height) / 2;
            tmp.Location = new Point(centerX, centerY);
            tmp.Show();

        }
        private void Form1_Resize(object sender, EventArgs e)
        {
            listView1.Size = new Size(listView1.Width, this.ClientSize.Height - 67);

        }
    }
}