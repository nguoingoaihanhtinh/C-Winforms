using System.Data;

namespace Bai02
{
        public partial class Form1 : Form
        { 
        protected double SavedData {get;set;}
        public Form1()
        {
            InitializeComponent();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button19.Text;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button20.Text;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button16.Text;
        }
        private void button13_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button13.Text;
        }
        private void button21_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button21.Text;
        }
        private void button18_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button18.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button6.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button4.Text;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button17.Text;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button5.Text;

        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (label1.Text.Length > 0) { 
                label1.Text = label1.Text.Remove(label1.Text.Length - 1, 1);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = "";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button14.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button11.Text;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button12.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button7.Text;
        }

        private void button23_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button23.Text;
        }
        private void button8_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + button8.Text;

        }
        private void button15_Click(object sender, EventArgs e)
        {
            string inputExpression = label1.Text;
            DataTable dataTable = new DataTable();
            object result = dataTable.Compute(inputExpression, "");
            if (double.TryParse(result.ToString(), out double number))
            {
                if (number.ToString().StartsWith("-"))
                {
                    label1.Text = number.ToString().Remove(0,1);
                }
                else
                {
                    label1.Text = "-" + number.ToString();
                }
            }
            else
            {
                MessageBox.Show("Invalid input for square root calculation.", "Error");
            }
        }
        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                string inputExpression = label1.Text;
                DataTable dataTable = new DataTable();
                object result = dataTable.Compute(inputExpression, "");
                if (result is double && double.IsInfinity((double)result))
                {
                    MessageBox.Show("Cannot divide by zero.", "Error");
                }
                else
                {
                    label1.Text = result.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            try
            {
                string inputExpression = label1.Text;
                DataTable dataTable = new DataTable();
                object result = dataTable.Compute(inputExpression, "");
                if (double.TryParse(result.ToString(), out double number) && number > 0)
                {
                    double sqrtResult = Math.Sqrt(number);
                    label1.Text = sqrtResult.ToString();
                }
                else
                {
                    MessageBox.Show("Invalid input for square root calculation.", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string inputExpression = label1.Text;
            DataTable dataTable = new DataTable();
            object result = dataTable.Compute(inputExpression, "");
            if (double.TryParse(result.ToString(), out double number) && number != 0)
            {
                double ans = 1 / number;
                label1.Text = ans.ToString();
            }
            else
            {
                MessageBox.Show("Invalid input for square root calculation.", "Error");
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {
            //MS BUTTON
            string inputExpression = label1.Text;
            DataTable dataTable = new DataTable();
            object result = dataTable.Compute(inputExpression, "");
            if (double.TryParse(result.ToString(), out double number))
            {
                label1.Text = number.ToString();
                SavedData = number;
            }
            else
            {
                MessageBox.Show("Invalid input for square root calculation.", "Error");
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            // MC BUTTON
            SavedData = 0;
        }

        private void button26_Click(object sender, EventArgs e)
        {
            //MR BUTTON
            label1.Text += SavedData.ToString();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            //M+ BUTTON
            string inputExpression = label1.Text;
            DataTable dataTable = new DataTable();
            object result = dataTable.Compute(inputExpression, "");
            if (double.TryParse(result.ToString(), out double number))
            {
                label1.Text = number.ToString();
                SavedData += number;
            }
            else
            {
                MessageBox.Show("Invalid input for square root calculation.", "Error");
            }
        }
    }
}