﻿using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace Bai1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("Tọa độ nhấp chuột là (" + e.X.ToString() + "," + e.Y.ToString() + ")");
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("Phím vừa bấm là '" + e.KeyChar.ToString() + "' với mã ASCII là " + ((int)e.KeyChar).ToString() + " và mã phím là " + keyCode);
        }
        string keyCode;
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            keyCode = e.KeyCode.ToString();
        }
    }
}
