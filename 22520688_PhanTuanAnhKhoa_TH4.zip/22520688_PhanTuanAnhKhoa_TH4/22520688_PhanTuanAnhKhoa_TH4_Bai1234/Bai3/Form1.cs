﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void openCtrlOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Video/Sound File | *.avi; *.mpeg; *.wav; *.midi; *.mp4; *.mp3";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.Text = Path.GetFileName(dialog.FileName);
                mediaPlayer.URL = dialog.FileName;
                mediaPlayer.Ctlcontrols.play();
            }
        }

        private void exitCtrlXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            current_Time.Text = "Hôm nay là ngày " + DateTime.Now.ToString("dd/MM/yyyy") + " - Bây giờ là " + DateTime.Now.ToString("HH:mm:ss tt").ToUpper();
        }

        private void mediaPlayer_Enter(object sender, EventArgs e)
        {

        }
    }
}
