﻿namespace Bai4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mainMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.newDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.openDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.saveDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.exitDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.formatMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newFile_Button = new System.Windows.Forms.ToolStripButton();
            this.saveFile_Button = new System.Windows.Forms.ToolStripButton();
            this.fontCombobox = new System.Windows.Forms.ToolStripComboBox();
            this.fontSizeCombobox = new System.Windows.Forms.ToolStripComboBox();
            this.bold = new System.Windows.Forms.ToolStripButton();
            this.italic = new System.Windows.Forms.ToolStripButton();
            this.underline = new System.Windows.Forms.ToolStripButton();
            this.textSpace = new System.Windows.Forms.RichTextBox();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mainMenu,
            this.formatMenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menu";
            // 
            // mainMenu
            // 
            this.mainMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newDocument,
            this.openDocument,
            this.saveDocument,
            this.exitDocument});
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Size = new System.Drawing.Size(69, 20);
            this.mainMenu.Text = "Hệ thống";
            // 
            // newDocument
            // 
            this.newDocument.Name = "newDocument";
            this.newDocument.Size = new System.Drawing.Size(190, 22);
            this.newDocument.Text = "Tạo văn bản mới";
            this.newDocument.Click += new System.EventHandler(this.newDocument_Click);
            // 
            // openDocument
            // 
            this.openDocument.Name = "openDocument";
            this.openDocument.Size = new System.Drawing.Size(190, 22);
            this.openDocument.Text = "Mở tập tin";
            this.openDocument.Click += new System.EventHandler(this.openDocument_Click);
            // 
            // saveDocument
            // 
            this.saveDocument.Name = "saveDocument";
            this.saveDocument.Size = new System.Drawing.Size(190, 22);
            this.saveDocument.Text = "Lưu nội dung văn bản";
            this.saveDocument.Click += new System.EventHandler(this.saveDocument_Click);
            // 
            // exitDocument
            // 
            this.exitDocument.Name = "exitDocument";
            this.exitDocument.Size = new System.Drawing.Size(190, 22);
            this.exitDocument.Text = "Thoát";
            this.exitDocument.Click += new System.EventHandler(this.exitDocument_Click);
            // 
            // formatMenu
            // 
            this.formatMenu.Name = "formatMenu";
            this.formatMenu.Size = new System.Drawing.Size(74, 20);
            this.formatMenu.Text = "Định dạng";
            this.formatMenu.Click += new System.EventHandler(this.formatMenu_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFile_Button,
            this.saveFile_Button,
            this.fontCombobox,
            this.fontSizeCombobox,
            this.bold,
            this.italic,
            this.underline});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newFile_Button
            // 
            this.newFile_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newFile_Button.Image = ((System.Drawing.Image)(resources.GetObject("newFile_Button.Image")));
            this.newFile_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newFile_Button.Name = "newFile_Button";
            this.newFile_Button.Size = new System.Drawing.Size(23, 22);
            this.newFile_Button.Text = "toolStripButton1";
            this.newFile_Button.Click += new System.EventHandler(this.newFile_Button_Click);
            // 
            // saveFile_Button
            // 
            this.saveFile_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveFile_Button.Image = ((System.Drawing.Image)(resources.GetObject("saveFile_Button.Image")));
            this.saveFile_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveFile_Button.Name = "saveFile_Button";
            this.saveFile_Button.Size = new System.Drawing.Size(23, 22);
            this.saveFile_Button.Text = "toolStripButton2";
            this.saveFile_Button.Click += new System.EventHandler(this.saveFile_Button_Click);
            // 
            // fontCombobox
            // 
            this.fontCombobox.Name = "fontCombobox";
            this.fontCombobox.Size = new System.Drawing.Size(121, 25);
            this.fontCombobox.TextChanged += new System.EventHandler(this.changeFontStyle);
            // 
            // fontSizeCombobox
            // 
            this.fontSizeCombobox.Name = "fontSizeCombobox";
            this.fontSizeCombobox.Size = new System.Drawing.Size(121, 25);
            // 
            // bold
            // 
            this.bold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bold.Image = ((System.Drawing.Image)(resources.GetObject("bold.Image")));
            this.bold.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bold.Name = "bold";
            this.bold.Size = new System.Drawing.Size(23, 22);
            this.bold.Text = "toolStripButton3";
            this.bold.Click += new System.EventHandler(this.bold_Click);
            // 
            // italic
            // 
            this.italic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.italic.Image = ((System.Drawing.Image)(resources.GetObject("italic.Image")));
            this.italic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.italic.Name = "italic";
            this.italic.Size = new System.Drawing.Size(23, 22);
            this.italic.Text = "toolStripButton4";
            this.italic.Click += new System.EventHandler(this.italic_Click);
            // 
            // underline
            // 
            this.underline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.underline.Image = ((System.Drawing.Image)(resources.GetObject("underline.Image")));
            this.underline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.underline.Name = "underline";
            this.underline.Size = new System.Drawing.Size(23, 22);
            this.underline.Text = "toolStripButton5";
            this.underline.Click += new System.EventHandler(this.underline_Click);
            // 
            // textSpace
            // 
            this.textSpace.Location = new System.Drawing.Point(0, 52);
            this.textSpace.Name = "textSpace";
            this.textSpace.Size = new System.Drawing.Size(800, 400);
            this.textSpace.TabIndex = 3;
            this.textSpace.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textSpace);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mainMenu;
        private System.Windows.Forms.ToolStripMenuItem newDocument;
        private System.Windows.Forms.ToolStripMenuItem openDocument;
        private System.Windows.Forms.ToolStripMenuItem saveDocument;
        private System.Windows.Forms.ToolStripMenuItem exitDocument;
        private System.Windows.Forms.ToolStripMenuItem formatMenu;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton newFile_Button;
        private System.Windows.Forms.ToolStripButton saveFile_Button;
        private System.Windows.Forms.ToolStripComboBox fontCombobox;
        private System.Windows.Forms.ToolStripComboBox fontSizeCombobox;
        private System.Windows.Forms.ToolStripButton bold;
        private System.Windows.Forms.ToolStripButton italic;
        private System.Windows.Forms.ToolStripButton underline;
        private System.Windows.Forms.RichTextBox textSpace;
    }
}

