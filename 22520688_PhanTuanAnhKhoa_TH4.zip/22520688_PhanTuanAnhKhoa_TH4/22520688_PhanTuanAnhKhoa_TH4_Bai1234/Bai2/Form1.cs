namespace Bai2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            clock.Start();
        }

        private void clock_Tick(object sender, EventArgs e)
        {
            txt_Time.Text = DateTime.Now.ToString("dddd, MMMM dd, yyyy HH:mm:ss tt");
            txt_Time.Left = (this.ClientSize.Width - txt_Time.Size.Width) / 2;
        }
    }
}