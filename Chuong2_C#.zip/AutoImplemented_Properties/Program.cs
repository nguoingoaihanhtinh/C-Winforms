﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImPro
{
    public class Person
    {
        string _Name;
        List<string> _Intersets = new List<string>(); //Khai bao _Intersets la mot danh sach kieu string
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public List<string> Interests
        {
            get { return _Intersets; }
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            /* Cach 1
            List<Person> PersonList = new List<Person>(); //Khai bao PersonList la danh sach kieu Person
            Person p1 = new Person();
            p1.Name = "Mony Hamza";
            p1.Interests.Add("Reading");
            p1.Interests.Add("Running");
            PersonList.Add(p1); //Them p1 co kieu Person vao danh sach PersonList
            Person p2 = new Person();
            p2.Name = "John Luke";
            p2.Interests.Add("Swimming");
            PersonList.Add(p2); //Them p2 co kieu Person vao danh sach PersonList

            */
            //Cach 2
            //Khai bao bien PersonList bang tu khoa var
            var PersonList = new List<Person> {
                new Person { Name = "Mony Luka", Interests = { "Reading", "Running" } },
                new Person { Name = "John Luke", Interests = { "Swimming" } }
                };
            Console.WriteLine("Hello PersonList:");
            foreach (var p in PersonList)
            {
                Console.Write(p.Name + " ");
                foreach (var inT in p.Interests)
                    Console.Write(inT + " ");
                Console.WriteLine();
            }
            Console.Read();
        }

    }
}

