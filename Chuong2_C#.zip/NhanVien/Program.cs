﻿using System;

public class NhanVien
{
    string name;
    public class Date
    {
        private int day;
        private int month;
        private int year;
        public void Nhap()
        {
            Console.WriteLine("Nhap ngay thang nam sinh: ");
            day = Convert.ToInt32(Console.ReadLine());
            month = Convert.ToInt32(Console.ReadLine());
            year = Convert.ToInt32(Console.ReadLine());
        }
        public void Out()
        {
            Console.WriteLine(day + "/" + month + "/" + year);
        }
    }
    private Date birth;
    public int luong { get; set; }
    public virtual void Nhap()
    {
        Console.WriteLine("Nhap vao ten nv: ");
        name = Console.ReadLine();
        birth = new Date();
        birth.Nhap();
    }
    
    public virtual int Luong()
    {
        return this.luong;
    }
    public void Xuat()
    {
        Console.WriteLine("Ten nhan vien: {0}", name);
        Console.WriteLine("ngay sinh: ");
        birth.Out();
        Console.WriteLine("Luong: {0}", this.luong);

    }
}
public class SanXuat : NhanVien
{
    private int sp;
    private int luongcb;
    public override void Nhap()
    {
        base.Nhap();
        Console.WriteLine("Nhap vao so san pham: ");
        sp = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Nhap vao luong co ban: ");
        luongcb = Convert.ToInt32(Console.ReadLine());
        this.luong = luongcb + sp * 5000;
    }
}
public class VanPhong : NhanVien
{
    private int ngaylam;
    public override void Nhap()
    {
        base.Nhap();
        Console.WriteLine("Nhap so ngay lam viec: ");
        ngaylam = Convert.ToInt32(Console.ReadLine());
        this.luong = ngaylam * 100000;
    }

}
class Program
{
    static void Main(string[] args)
    {
        NhanVien[] a = new NhanVien[100];
        int n;
        Console.WriteLine("Nhap vao so luong nhan vien: ");
        n = Convert.ToInt32(Console.ReadLine());
        for(int i = 0; i < n; i++)
        {
            Console.WriteLine("Nhap loai nhan vien: ");
            Console.WriteLine("1.Nhan vien san xuat ");
            Console.WriteLine("2.Nhan vien van phong ");
            int chose = Convert.ToInt32(Console.ReadLine());
            if(chose == 1)
            {
                a[i] = new SanXuat();
            }
            else { a[i] = new VanPhong(); }
            a[i].Nhap();
        }
        for(int i = 0; i < n; i++)
        {
            a[i].Xuat();
        }
        
        int sum = 0;
        for(int i = 0; i < n; i++)
        {
            sum += a[i].Luong();
        }
        Console.WriteLine("Tong luong cong ty phai tra: " + sum);
        int max = 0; int index = 0;
        for(int i = 0; i < n; i++)
        {
            if (a[i].Luong() > max)
            {
                max = a[i].Luong();
                index = i;
            }
        }
        Console.WriteLine("Nhan vien co luong cao nhat la: ");
        a[index].Xuat();
    }
    
}