﻿using System;

public class ThoiGian
{
    public void ThoiGianHienHanh()
    {
        //Console.WriteLine("Hien thi thoi gian ");
        System.DateTime now = System.DateTime.Now;
        System.Console.WriteLine("\nHien tai: \t {0}/{1}/{2}{3}:{4}:{5}", now.Day, now.Month, now.Year, now.Hour, now.Minute, now.Second);
        System.Console.WriteLine("Thoi gian: \t {0}/{1}/{2}{3}:{4}:{5}", ngay, thang, nam, gio, phut, giay);

    }
    public ThoiGian(System.DateTime dt)
    {
        nam = dt.Year; thang = dt.Month; ngay = dt.Day; gio = dt.Hour; phut = dt.Minute; giay = dt.Second;
    }
    public ThoiGian(int year, int month, int day, int hour, int minute)
    {
        nam = year; thang = month; ngay = day; gio = hour; phut = minute;
    }
    int nam;
    int thang;
    int ngay;
    int gio; int phut; int giay = 30;
}
public class Tester
{
    static void Main()
    {
        System.DateTime currentTime = System.DateTime.Now;
        ThoiGian t1 = new ThoiGian(currentTime);
        t1.ThoiGianHienHanh();
        ThoiGian t2 = new ThoiGian(2004, 4, 21, 10, 5);
        t2.ThoiGianHienHanh();
    }

}

