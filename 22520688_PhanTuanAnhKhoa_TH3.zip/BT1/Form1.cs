namespace BT1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rd = new Random();
            Color randomColor = Color.FromArgb(rd.Next(256), rd.Next(256), rd.Next(255));
            this.BackColor = randomColor;
        }
    
    }
}