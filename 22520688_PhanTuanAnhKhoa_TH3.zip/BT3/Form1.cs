﻿namespace BT3
{
    public partial class Form1 : Form
    {
        int index;
        public Form1()
        {
            InitializeComponent();
        }
        private bool isValidNumber()
        {
            double a;
            if (txt_num1.Text == "" || txt_num2.Text == "")
            {
                MessageBox.Show("Không được để trống");
                return false;
            }
            try
            {
                a = double.Parse(txt_num1.Text) + double.Parse(txt_num2.Text);
            }
            catch (FormatException)
            {
                txt_num1.Text = txt_num2.Text = "";
                MessageBox.Show("Giá trị nhập vào không hợp lệ, hãy nhập lại");
                return false;
            }
            return true;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                index = 1;
            }
            if (comboBox1.SelectedIndex == 1)
            {
                index = 2;
            }
            if (comboBox1.SelectedIndex == 2)
            {
                index = 3;
            }
                        if (comboBox1.SelectedIndex == 3)
                        {
                            index = 4;
                        }
                    
                
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(index == 1)
            {
                if (isValidNumber())
                    txt_result.Text = (double.Parse(txt_num1.Text) + double.Parse(txt_num2.Text)).ToString();
            }
            if(index == 2)
            {
                if (isValidNumber())
                    txt_result.Text = (double.Parse(txt_num1.Text) - double.Parse(txt_num2.Text)).ToString();
            }
            if((index == 3) && isValidNumber())
            {
                    txt_result.Text = (double.Parse(txt_num1.Text) * double.Parse(txt_num2.Text)).ToString();
            }
            if((index == 4) && isValidNumber())
            {
                    txt_result.Text = (double.Parse(txt_num1.Text) / double.Parse(txt_num2.Text)).ToString();
            }
        }
    }
}