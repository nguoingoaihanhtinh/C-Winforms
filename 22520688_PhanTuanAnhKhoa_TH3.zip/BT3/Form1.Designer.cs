﻿namespace BT3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_num1 = new Label();
            lbl_num2 = new Label();
            lbl_op = new Label();
            lbl_result = new Label();
            txt_num1 = new TextBox();
            txt_num2 = new TextBox();
            txt_result = new TextBox();
            comboBox1 = new ComboBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // lbl_num1
            // 
            lbl_num1.AutoSize = true;
            lbl_num1.Location = new Point(13, 17);
            lbl_num1.Name = "lbl_num1";
            lbl_num1.Size = new Size(63, 15);
            lbl_num1.TabIndex = 0;
            lbl_num1.Text = "Number 1:";
            // 
            // lbl_num2
            // 
            lbl_num2.AutoSize = true;
            lbl_num2.Location = new Point(12, 43);
            lbl_num2.Name = "lbl_num2";
            lbl_num2.Size = new Size(63, 15);
            lbl_num2.TabIndex = 1;
            lbl_num2.Text = "Number 2:";
            // 
            // lbl_op
            // 
            lbl_op.AutoSize = true;
            lbl_op.Location = new Point(12, 69);
            lbl_op.Name = "lbl_op";
            lbl_op.Size = new Size(57, 15);
            lbl_op.TabIndex = 2;
            lbl_op.Text = "Operator:";
            // 
            // lbl_result
            // 
            lbl_result.AutoSize = true;
            lbl_result.Location = new Point(13, 124);
            lbl_result.Name = "lbl_result";
            lbl_result.Size = new Size(42, 15);
            lbl_result.TabIndex = 3;
            lbl_result.Text = "Result:";
            // 
            // txt_num1
            // 
            txt_num1.Location = new Point(82, 14);
            txt_num1.Name = "txt_num1";
            txt_num1.Size = new Size(120, 23);
            txt_num1.TabIndex = 4;
            // 
            // txt_num2
            // 
            txt_num2.Location = new Point(81, 40);
            txt_num2.Name = "txt_num2";
            txt_num2.Size = new Size(121, 23);
            txt_num2.TabIndex = 5;
            // 
            // txt_result
            // 
            txt_result.Location = new Point(82, 121);
            txt_result.Name = "txt_result";
            txt_result.Size = new Size(120, 23);
            txt_result.TabIndex = 6;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "+", "-", "*", "/" });
            comboBox1.Location = new Point(81, 66);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 7;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Location = new Point(82, 92);
            button1.Name = "button1";
            button1.Size = new Size(120, 23);
            button1.TabIndex = 8;
            button1.Text = "Execute";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(comboBox1);
            Controls.Add(txt_result);
            Controls.Add(txt_num2);
            Controls.Add(txt_num1);
            Controls.Add(lbl_result);
            Controls.Add(lbl_op);
            Controls.Add(lbl_num2);
            Controls.Add(lbl_num1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_num1;
        private Label lbl_num2;
        private Label lbl_op;
        private Label lbl_result;
        private TextBox txt_num1;
        private TextBox txt_num2;
        private TextBox txt_result;
        private ComboBox comboBox1;
        private Button button1;
    }
}