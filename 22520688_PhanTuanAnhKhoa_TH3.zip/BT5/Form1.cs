﻿namespace BT5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private bool isValidInfo()
        {
            bool isValid = true;
            if (txt_num.Text == "" || txt_name.Text == "" || txt_addr.Text == "" || txt_mny.Text == "")
                isValid = false;
            foreach (char c in txt_num.Text)
                if ((int)c < (int)'0' || (int)c > (int)'9')
                {
                    txt_num.Text = "";
                    isValid = false;
                }
            foreach (char c in txt_name.Text)
                if ((int)c >= (int)'0' && (int)c <= (int)'9')
                {
                    txt_name.Text = "";
                    isValid = false;
                }
            foreach (char c in txt_mny.Text)
                if ((int)c < (int)'0' || (int)c > (int)'9')
                {
                    txt_mny.Text = "";
                    isValid = false;
                }
            return isValid;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (isValidInfo())
            {
                foreach (ListViewItem item in listView.Items)
                    if (item.SubItems[1].Text == txt_num.Text)
                    {
                        item.SubItems[2].Text = txt_name.Text;
                        item.SubItems[3].Text = txt_addr.Text;
                        item.SubItems[4].Text = long.Parse(txt_mny.Text).ToString();
                        MessageBox.Show("Cập nhật dữ liệu thành công!");
                        return;
                    }
                ListViewItem addItem = new ListViewItem((listView.Items.Count + 1).ToString());
                addItem.SubItems.Add(txt_num.Text);
                addItem.SubItems.Add(txt_name.Text);
                addItem.SubItems.Add(txt_addr.Text);
                addItem.SubItems.Add(long.Parse(txt_mny.Text).ToString());
                listView.Items.Add(addItem);
                MessageBox.Show("Thêm mới dữ liệu thành công!");
                txt_num.Text = txt_name.Text = txt_mny.Text = txt_addr.Text = "";
            }
            else MessageBox.Show("Vui lòng nhập đầy đủ và chính xác thông tin!");
        }

        private void btn_Del_Click(object sender, EventArgs e)
        {
            if (listView.Items.Count == 0)
            {
                MessageBox.Show("Bảng chưa có thông tin");
                return;
            }
            else
            {
                ListViewItem removeIndexItem = null;
                foreach (ListViewItem item in listView.Items)
                    if (item.Selected == true || item.SubItems[1].Text == txt_num.Text)
                        removeIndexItem = item;
                if (removeIndexItem != null)
                {
                    if (MessageBox.Show("Bạn có chắc chắn muốn xóa?", "XÁC NHẬN XÓA", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        removeIndexItem.Remove();
                        MessageBox.Show("Xóa tài khoản thành công");
                        txt_num.Text = txt_name.Text = txt_mny.Text = txt_addr.Text = "";
                        for (int i = 0; i < listView.Items.Count; i++)
                            listView.Items[i].SubItems[0].Text = (i + 1).ToString();
                    }
                }
                else MessageBox.Show("Không tìm thấy số tài khoản cần xóa");
            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Bạn có chắc chắn muốn thoát?", "XÁC NHẬN THOÁT CHƯƠNG TRÌNH", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}