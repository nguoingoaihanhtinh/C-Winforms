﻿namespace BT5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lbl_num = new Label();
            lbl_name = new Label();
            lbl_addr = new Label();
            lbl_mny = new Label();
            txt_num = new TextBox();
            txt_name = new TextBox();
            txt_addr = new TextBox();
            txt_mny = new TextBox();
            btn_Add = new Button();
            btn_Del = new Button();
            btn_Exit = new Button();
            listView = new ListView();
            order = new ColumnHeader();
            id = new ColumnHeader();
            name = new ColumnHeader();
            address = new ColumnHeader();
            money = new ColumnHeader();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(0, 0, 192);
            label1.Location = new Point(81, 9);
            label1.Name = "label1";
            label1.Size = new Size(620, 54);
            label1.TabIndex = 0;
            label1.Text = "QUẢN LÝ THÔNG TIN TÀI KHOẢN";
            // 
            // lbl_num
            // 
            lbl_num.AutoSize = true;
            lbl_num.FlatStyle = FlatStyle.System;
            lbl_num.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_num.Location = new Point(139, 80);
            lbl_num.Name = "lbl_num";
            lbl_num.Size = new Size(85, 19);
            lbl_num.TabIndex = 1;
            lbl_num.Text = "Số tài khoản";
            // 
            // lbl_name
            // 
            lbl_name.AutoSize = true;
            lbl_name.FlatStyle = FlatStyle.System;
            lbl_name.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_name.Location = new Point(121, 105);
            lbl_name.Name = "lbl_name";
            lbl_name.Size = new Size(105, 19);
            lbl_name.TabIndex = 2;
            lbl_name.Text = "Tên khách hàng";
            // 
            // lbl_addr
            // 
            lbl_addr.AutoSize = true;
            lbl_addr.FlatStyle = FlatStyle.System;
            lbl_addr.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_addr.Location = new Point(103, 130);
            lbl_addr.Name = "lbl_addr";
            lbl_addr.Size = new Size(125, 19);
            lbl_addr.TabIndex = 3;
            lbl_addr.Text = "Địa chỉ khách hàng";
            // 
            // lbl_mny
            // 
            lbl_mny.AutoSize = true;
            lbl_mny.FlatStyle = FlatStyle.System;
            lbl_mny.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_mny.Location = new Point(84, 157);
            lbl_mny.Name = "lbl_mny";
            lbl_mny.Size = new Size(150, 19);
            lbl_mny.TabIndex = 4;
            lbl_mny.Text = "Số tiền trong tài khoản";
            // 
            // txt_num
            // 
            txt_num.Location = new Point(230, 79);
            txt_num.Name = "txt_num";
            txt_num.Size = new Size(413, 23);
            txt_num.TabIndex = 5;
            // 
            // txt_name
            // 
            txt_name.Location = new Point(230, 104);
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(413, 23);
            txt_name.TabIndex = 6;
            // 
            // txt_addr
            // 
            txt_addr.Location = new Point(230, 129);
            txt_addr.Name = "txt_addr";
            txt_addr.Size = new Size(413, 23);
            txt_addr.TabIndex = 7;
            // 
            // txt_mny
            // 
            txt_mny.Location = new Point(230, 156);
            txt_mny.Name = "txt_mny";
            txt_mny.Size = new Size(413, 23);
            txt_mny.TabIndex = 8;
            // 
            // btn_Add
            // 
            btn_Add.Location = new Point(340, 194);
            btn_Add.Name = "btn_Add";
            btn_Add.Size = new Size(107, 23);
            btn_Add.TabIndex = 9;
            btn_Add.Text = "Thêm / Cập nhật";
            btn_Add.UseVisualStyleBackColor = true;
            btn_Add.Click += btn_Add_Click;
            // 
            // btn_Del
            // 
            btn_Del.Location = new Point(482, 194);
            btn_Del.Name = "btn_Del";
            btn_Del.Size = new Size(65, 23);
            btn_Del.TabIndex = 10;
            btn_Del.Text = "Xóa";
            btn_Del.UseVisualStyleBackColor = true;
            btn_Del.Click += btn_Del_Click;
            // 
            // btn_Exit
            // 
            btn_Exit.Location = new Point(578, 194);
            btn_Exit.Name = "btn_Exit";
            btn_Exit.Size = new Size(65, 23);
            btn_Exit.TabIndex = 11;
            btn_Exit.Text = "Thoát";
            btn_Exit.UseVisualStyleBackColor = true;
            btn_Exit.Click += btn_Exit_Click;
            // 
            // listView
            // 
            listView.Columns.AddRange(new ColumnHeader[] { order, id, name, address, money });
            listView.GridLines = true;
            listView.Location = new Point(12, 223);
            listView.Name = "listView";
            listView.Size = new Size(784, 201);
            listView.TabIndex = 12;
            listView.UseCompatibleStateImageBehavior = false;
            listView.View = View.Details;
            // 
            // order
            // 
            order.Text = "STT";
            // 
            // id
            // 
            id.Text = "Mã tài khoản";
            id.Width = 110;
            // 
            // name
            // 
            name.Text = "Tên khách hàng";
            name.Width = 250;
            // 
            // address
            // 
            address.Text = "Địa chỉ";
            address.Width = 250;
            // 
            // money
            // 
            money.Text = "Số tờ";
            money.Width = 110;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listView);
            Controls.Add(btn_Exit);
            Controls.Add(btn_Del);
            Controls.Add(btn_Add);
            Controls.Add(txt_mny);
            Controls.Add(txt_addr);
            Controls.Add(txt_name);
            Controls.Add(txt_num);
            Controls.Add(lbl_mny);
            Controls.Add(lbl_addr);
            Controls.Add(lbl_name);
            Controls.Add(lbl_num);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lbl_num;
        private Label lbl_name;
        private Label lbl_addr;
        private Label lbl_mny;
        private TextBox txt_num;
        private TextBox txt_name;
        private TextBox txt_addr;
        private TextBox txt_mny;
        private Button btn_Add;
        private Button btn_Del;
        private Button btn_Exit;
        private ListView listView;
        private ColumnHeader order;
        private ColumnHeader id;
        private ColumnHeader name;
        private ColumnHeader address;
        private ColumnHeader money;
    }
}