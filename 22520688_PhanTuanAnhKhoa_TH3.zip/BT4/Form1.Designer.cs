﻿namespace BT4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            label2 = new Label();
            txt_payment = new TextBox();
            btn_Select = new Button();
            btn_Cancel = new Button();
            btn_End = new Button();
            colorDialog1 = new ColorDialog();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.AppWorkspace;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(2, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(798, 100);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.AppWorkspace;
            label1.Font = new Font("Segoe UI", 35F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(255, 128, 0);
            label1.Location = new Point(141, 21);
            label1.Name = "label1";
            label1.Size = new Size(276, 62);
            label1.TabIndex = 0;
            label1.Text = "MÀN ẢNH";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            button1.AllowDrop = true;
            button1.BackColor = Color.White;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(79, 129);
            button1.Name = "button1";
            button1.Size = new Size(75, 62);
            button1.TabIndex = 1;
            button1.Tag = "A";
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            button1.MouseClick += chooseNumber;
            // 
            // button2
            // 
            button2.AllowDrop = true;
            button2.BackColor = Color.White;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(160, 129);
            button2.Name = "button2";
            button2.Size = new Size(75, 62);
            button2.TabIndex = 2;
            button2.Tag = "A";
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.MouseClick += chooseNumber;
            // 
            // button3
            // 
            button3.AllowDrop = true;
            button3.BackColor = Color.White;
            button3.FlatStyle = FlatStyle.Popup;
            button3.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(241, 129);
            button3.Name = "button3";
            button3.Size = new Size(75, 62);
            button3.TabIndex = 3;
            button3.Tag = "A";
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.MouseClick += chooseNumber;
            // 
            // button4
            // 
            button4.AllowDrop = true;
            button4.BackColor = Color.White;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(322, 129);
            button4.Name = "button4";
            button4.Size = new Size(75, 62);
            button4.TabIndex = 4;
            button4.Tag = "A";
            button4.Text = "4";
            button4.UseVisualStyleBackColor = false;
            button4.MouseClick += chooseNumber;
            // 
            // button5
            // 
            button5.AllowDrop = true;
            button5.BackColor = Color.White;
            button5.FlatStyle = FlatStyle.Popup;
            button5.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(403, 129);
            button5.Name = "button5";
            button5.Size = new Size(75, 62);
            button5.TabIndex = 5;
            button5.Tag = "A";
            button5.Text = "5";
            button5.UseVisualStyleBackColor = false;
            button5.MouseClick += chooseNumber;
            // 
            // button6
            // 
            button6.AllowDrop = true;
            button6.BackColor = Color.White;
            button6.FlatStyle = FlatStyle.Popup;
            button6.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(403, 197);
            button6.Name = "button6";
            button6.Size = new Size(75, 62);
            button6.TabIndex = 10;
            button6.Tag = "B";
            button6.Text = "10";
            button6.UseVisualStyleBackColor = false;
            button6.MouseClick += chooseNumber;
            // 
            // button7
            // 
            button7.AllowDrop = true;
            button7.BackColor = Color.White;
            button7.FlatStyle = FlatStyle.Popup;
            button7.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(322, 197);
            button7.Name = "button7";
            button7.Size = new Size(75, 62);
            button7.TabIndex = 9;
            button7.Tag = "B";
            button7.Text = "9";
            button7.UseVisualStyleBackColor = false;
            button7.MouseClick += chooseNumber;
            // 
            // button8
            // 
            button8.AllowDrop = true;
            button8.BackColor = Color.White;
            button8.FlatStyle = FlatStyle.Popup;
            button8.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button8.Location = new Point(241, 197);
            button8.Name = "button8";
            button8.Size = new Size(75, 62);
            button8.TabIndex = 8;
            button8.Tag = "B";
            button8.Text = "8";
            button8.UseVisualStyleBackColor = false;
            button8.MouseClick += chooseNumber;
            // 
            // button9
            // 
            button9.AllowDrop = true;
            button9.BackColor = Color.White;
            button9.FlatStyle = FlatStyle.Popup;
            button9.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button9.Location = new Point(160, 197);
            button9.Name = "button9";
            button9.Size = new Size(75, 62);
            button9.TabIndex = 7;
            button9.Tag = "B";
            button9.Text = "7";
            button9.UseVisualStyleBackColor = false;
            button9.MouseClick += chooseNumber;
            // 
            // button10
            // 
            button10.AllowDrop = true;
            button10.BackColor = Color.White;
            button10.FlatStyle = FlatStyle.Popup;
            button10.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button10.Location = new Point(79, 197);
            button10.Name = "button10";
            button10.Size = new Size(75, 62);
            button10.TabIndex = 6;
            button10.Tag = "B";
            button10.Text = "6";
            button10.UseVisualStyleBackColor = false;
            button10.MouseClick += chooseNumber;
            // 
            // button11
            // 
            button11.AllowDrop = true;
            button11.BackColor = Color.White;
            button11.FlatStyle = FlatStyle.Popup;
            button11.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button11.Location = new Point(403, 265);
            button11.Name = "button11";
            button11.Size = new Size(75, 62);
            button11.TabIndex = 15;
            button11.Tag = "C";
            button11.Text = "15";
            button11.UseVisualStyleBackColor = false;
            button11.MouseClick += chooseNumber;
            // 
            // button12
            // 
            button12.AllowDrop = true;
            button12.BackColor = Color.White;
            button12.FlatStyle = FlatStyle.Popup;
            button12.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button12.Location = new Point(322, 265);
            button12.Name = "button12";
            button12.Size = new Size(75, 62);
            button12.TabIndex = 14;
            button12.Tag = "C";
            button12.Text = "14";
            button12.UseVisualStyleBackColor = false;
            button12.MouseClick += chooseNumber;
            // 
            // button13
            // 
            button13.AllowDrop = true;
            button13.BackColor = Color.White;
            button13.FlatStyle = FlatStyle.Popup;
            button13.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button13.Location = new Point(241, 265);
            button13.Name = "button13";
            button13.Size = new Size(75, 62);
            button13.TabIndex = 13;
            button13.Tag = "C";
            button13.Text = "13";
            button13.UseVisualStyleBackColor = false;
            button13.MouseClick += chooseNumber;
            // 
            // button14
            // 
            button14.AllowDrop = true;
            button14.BackColor = Color.White;
            button14.FlatStyle = FlatStyle.Popup;
            button14.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button14.Location = new Point(160, 265);
            button14.Name = "button14";
            button14.Size = new Size(75, 62);
            button14.TabIndex = 12;
            button14.Tag = "C";
            button14.Text = "12";
            button14.UseVisualStyleBackColor = false;
            button14.MouseClick += chooseNumber;
            // 
            // button15
            // 
            button15.AllowDrop = true;
            button15.BackColor = Color.White;
            button15.FlatStyle = FlatStyle.Popup;
            button15.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            button15.Location = new Point(79, 265);
            button15.Name = "button15";
            button15.Size = new Size(75, 62);
            button15.TabIndex = 11;
            button15.Tag = "C";
            button15.Text = "11";
            button15.UseVisualStyleBackColor = false;
            button15.MouseClick += chooseNumber;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(22, 351);
            label2.Name = "label2";
            label2.Size = new Size(98, 25);
            label2.TabIndex = 16;
            label2.Text = "Thành tiền:";
            // 
            // txt_payment
            // 
            txt_payment.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            txt_payment.Location = new Point(122, 348);
            txt_payment.Name = "txt_payment";
            txt_payment.Size = new Size(412, 31);
            txt_payment.TabIndex = 18;
            // 
            // btn_Select
            // 
            btn_Select.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            btn_Select.Location = new Point(113, 397);
            btn_Select.Name = "btn_Select";
            btn_Select.Size = new Size(94, 41);
            btn_Select.TabIndex = 19;
            btn_Select.Text = "Chon";
            btn_Select.UseVisualStyleBackColor = true;
            btn_Select.Click += btn_Select_Click;
            // 
            // btn_Cancel
            // 
            btn_Cancel.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            btn_Cancel.Location = new Point(231, 397);
            btn_Cancel.Name = "btn_Cancel";
            btn_Cancel.Size = new Size(94, 41);
            btn_Cancel.TabIndex = 20;
            btn_Cancel.Text = "Huy Bo";
            btn_Cancel.UseVisualStyleBackColor = true;
            btn_Cancel.Click += btn_Cancel_Click;
            // 
            // btn_End
            // 
            btn_End.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            btn_End.Location = new Point(345, 397);
            btn_End.Name = "btn_End";
            btn_End.Size = new Size(94, 41);
            btn_End.TabIndex = 21;
            btn_End.Text = "Ket Thuc";
            btn_End.UseVisualStyleBackColor = true;
            btn_End.Click += btn_End_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(572, 450);
            Controls.Add(btn_End);
            Controls.Add(btn_Cancel);
            Controls.Add(btn_Select);
            Controls.Add(txt_payment);
            Controls.Add(label2);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Rap Chieu Phim";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Label label2;
        private TextBox txt_payment;
        private Button btn_Select;
        private Button btn_Cancel;
        private Button btn_End;
        private ColorDialog colorDialog1;
    }
}