﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Control control = (Control)sender;
            if (!Char.IsDigit(control.Text[control.Text.Length - 1]))
                this.errorProvider1.SetError(control, "this is not a valid number");
            else this.errorProvider1.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void BtnAdd_click(object sender, EventArgs e)
        {
            int sum;
            sum = int.Parse(txt1.Text) + int.Parse(txt2.Text);
            MessageBox.Show("Sum: " + sum.ToString());
        }
      
      

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Control control = (Control)sender;
            if (!Char.IsDigit(control.Text[control.Text.Length - 1]))
                this.errorProvider1.SetError(control, "this is not a valid number");
            else this.errorProvider1.Clear();
        }
    }
}
