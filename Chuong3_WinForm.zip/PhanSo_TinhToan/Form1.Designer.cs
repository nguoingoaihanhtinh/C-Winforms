﻿using System.Runtime.CompilerServices;

namespace PhanSo_TinhToan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PS1 = new System.Windows.Forms.Label();
            this.TuSo1 = new System.Windows.Forms.Label();
            this.MauSo1 = new System.Windows.Forms.Label();
            this.PhepTinh = new System.Windows.Forms.Label();
            this.MauSo2 = new System.Windows.Forms.Label();
            this.TuSo2 = new System.Windows.Forms.Label();
            this.PS2 = new System.Windows.Forms.Label();
            this.txttu1 = new System.Windows.Forms.TextBox();
            this.txtmau1 = new System.Windows.Forms.TextBox();
            this.txttu2 = new System.Windows.Forms.TextBox();
            this.txtmau2 = new System.Windows.Forms.TextBox();
            this.BtnMinus = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnTimes = new System.Windows.Forms.Button();
            this.BtnDivided = new System.Windows.Forms.Button();
            this.txtkqtu = new System.Windows.Forms.TextBox();
            this.txtkqmau = new System.Windows.Forms.TextBox();
            this.KqMau = new System.Windows.Forms.Label();
            this.KqTu = new System.Windows.Forms.Label();
            this.groupKq = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PS1
            // 
            this.PS1.AutoSize = true;
            this.PS1.Location = new System.Drawing.Point(39, 33);
            this.PS1.Name = "PS1";
            this.PS1.Size = new System.Drawing.Size(62, 16);
            this.PS1.TabIndex = 0;
            this.PS1.Text = "PhanSo1";
            this.PS1.Click += new System.EventHandler(this.label1_Click);
            // 
            // TuSo1
            // 
            this.TuSo1.AutoSize = true;
            this.TuSo1.Location = new System.Drawing.Point(39, 64);
            this.TuSo1.Name = "TuSo1";
            this.TuSo1.Size = new System.Drawing.Size(40, 16);
            this.TuSo1.TabIndex = 1;
            this.TuSo1.Text = "TuSo";
            this.TuSo1.Click += new System.EventHandler(this.label2_Click);
            // 
            // MauSo1
            // 
            this.MauSo1.AutoSize = true;
            this.MauSo1.Location = new System.Drawing.Point(39, 96);
            this.MauSo1.Name = "MauSo1";
            this.MauSo1.Size = new System.Drawing.Size(50, 16);
            this.MauSo1.TabIndex = 2;
            this.MauSo1.Text = "MauSo";
            this.MauSo1.Click += new System.EventHandler(this.label3_Click);
            // 
            // PhepTinh
            // 
            this.PhepTinh.AutoSize = true;
            this.PhepTinh.Location = new System.Drawing.Point(115, 142);
            this.PhepTinh.Name = "PhepTinh";
            this.PhepTinh.Size = new System.Drawing.Size(65, 16);
            this.PhepTinh.TabIndex = 5;
            this.PhepTinh.Text = "PhepTinh";
            this.PhepTinh.Enter += new System.EventHandler(this.grBox_PhepTinh);
            // 
            // MauSo2
            // 
            this.MauSo2.AutoSize = true;
            this.MauSo2.Location = new System.Drawing.Point(224, 96);
            this.MauSo2.Name = "MauSo2";
            this.MauSo2.Size = new System.Drawing.Size(50, 16);
            this.MauSo2.TabIndex = 8;
            this.MauSo2.Text = "MauSo";
            // 
            // TuSo2
            // 
            this.TuSo2.AutoSize = true;
            this.TuSo2.Location = new System.Drawing.Point(224, 64);
            this.TuSo2.Name = "TuSo2";
            this.TuSo2.Size = new System.Drawing.Size(40, 16);
            this.TuSo2.TabIndex = 7;
            this.TuSo2.Text = "TuSo";
            this.TuSo2.Click += new System.EventHandler(this.label8_Click);
            // 
            // PS2
            // 
            this.PS2.AutoSize = true;
            this.PS2.Location = new System.Drawing.Point(224, 33);
            this.PS2.Name = "PS2";
            this.PS2.Size = new System.Drawing.Size(62, 16);
            this.PS2.TabIndex = 6;
            this.PS2.Text = "PhanSo2";
            // 
            // txttu1
            // 
            this.txttu1.Location = new System.Drawing.Point(95, 61);
            this.txttu1.Name = "txttu1";
            this.txttu1.Size = new System.Drawing.Size(100, 22);
            this.txttu1.TabIndex = 9;
            this.txttu1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtmau1
            // 
            this.txtmau1.Location = new System.Drawing.Point(95, 93);
            this.txtmau1.Name = "txtmau1";
            this.txtmau1.Size = new System.Drawing.Size(100, 22);
            this.txtmau1.TabIndex = 10;
            // 
            // txttu2
            // 
            this.txttu2.Location = new System.Drawing.Point(280, 64);
            this.txttu2.Name = "txttu2";
            this.txttu2.Size = new System.Drawing.Size(100, 22);
            this.txttu2.TabIndex = 12;
            this.txttu2.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtmau2
            // 
            this.txtmau2.Location = new System.Drawing.Point(280, 96);
            this.txtmau2.Name = "txtmau2";
            this.txtmau2.Size = new System.Drawing.Size(100, 22);
            this.txtmau2.TabIndex = 11;
            this.txtmau2.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // BtnMinus
            // 
            this.BtnMinus.Location = new System.Drawing.Point(166, 173);
            this.BtnMinus.Name = "BtnMinus";
            this.BtnMinus.Size = new System.Drawing.Size(75, 23);
            this.BtnMinus.TabIndex = 13;
            this.BtnMinus.Text = "Tru";
            this.BtnMinus.UseVisualStyleBackColor = true;
            this.BtnMinus.Click += new System.EventHandler(this.BtnMinus_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Location = new System.Drawing.Point(55, 173);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(75, 23);
            this.BtnAdd.TabIndex = 14;
            this.BtnAdd.Text = "Cong";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnTimes
            // 
            this.BtnTimes.Location = new System.Drawing.Point(55, 213);
            this.BtnTimes.Name = "BtnTimes";
            this.BtnTimes.Size = new System.Drawing.Size(75, 23);
            this.BtnTimes.TabIndex = 15;
            this.BtnTimes.Text = "Nhan";
            this.BtnTimes.UseVisualStyleBackColor = true;
            this.BtnTimes.Click += new System.EventHandler(this.BtnTimes_Click);
            // 
            // BtnDivided
            // 
            this.BtnDivided.Location = new System.Drawing.Point(166, 213);
            this.BtnDivided.Name = "BtnDivided";
            this.BtnDivided.Size = new System.Drawing.Size(75, 23);
            this.BtnDivided.TabIndex = 16;
            this.BtnDivided.Text = "Chia";
            this.BtnDivided.UseVisualStyleBackColor = true;
            this.BtnDivided.Click += new System.EventHandler(this.BtnDivided_Click);
            // 
            // txtkqtu
            // 
            this.txtkqtu.Location = new System.Drawing.Point(576, 64);
            this.txtkqtu.Name = "txtkqtu";
            this.txtkqtu.Size = new System.Drawing.Size(100, 22);
            this.txtkqtu.TabIndex = 21;
            // 
            // txtkqmau
            // 
            this.txtkqmau.Location = new System.Drawing.Point(576, 96);
            this.txtkqmau.Name = "txtkqmau";
            this.txtkqmau.Size = new System.Drawing.Size(100, 22);
            this.txtkqmau.TabIndex = 20;
            // 
            // KqMau
            // 
            this.KqMau.AutoSize = true;
            this.KqMau.Location = new System.Drawing.Point(520, 96);
            this.KqMau.Name = "KqMau";
            this.KqMau.Size = new System.Drawing.Size(50, 16);
            this.KqMau.TabIndex = 19;
            this.KqMau.Text = "MauSo";
            // 
            // KqTu
            // 
            this.KqTu.AutoSize = true;
            this.KqTu.Location = new System.Drawing.Point(520, 64);
            this.KqTu.Name = "KqTu";
            this.KqTu.Size = new System.Drawing.Size(40, 16);
            this.KqTu.TabIndex = 18;
            this.KqTu.Text = "TuSo";
            // 
            // groupKq
            // 
            this.groupKq.AutoSize = true;
            this.groupKq.Location = new System.Drawing.Point(520, 33);
            this.groupKq.Name = "groupKq";
            this.groupKq.Size = new System.Drawing.Size(51, 16);
            this.groupKq.TabIndex = 17;
            this.groupKq.Text = "KetQua";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(304, 192);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "Continue";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.BtnContinue_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(457, 192);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 23);
            this.button2.TabIndex = 23;
            this.button2.Text = "Stop";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.BtnOut_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 265);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtkqtu);
            this.Controls.Add(this.txtkqmau);
            this.Controls.Add(this.KqMau);
            this.Controls.Add(this.KqTu);
            this.Controls.Add(this.groupKq);
            this.Controls.Add(this.BtnDivided);
            this.Controls.Add(this.BtnTimes);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.BtnMinus);
            this.Controls.Add(this.txttu2);
            this.Controls.Add(this.txtmau2);
            this.Controls.Add(this.txtmau1);
            this.Controls.Add(this.txttu1);
            this.Controls.Add(this.MauSo2);
            this.Controls.Add(this.TuSo2);
            this.Controls.Add(this.PS2);
            this.Controls.Add(this.PhepTinh);
            this.Controls.Add(this.MauSo1);
            this.Controls.Add(this.TuSo1);
            this.Controls.Add(this.PS1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PS1;
        private System.Windows.Forms.Label TuSo1;
        private System.Windows.Forms.Label MauSo1;
        private System.Windows.Forms.Label PhepTinh;
        private System.Windows.Forms.Label MauSo2;
        private System.Windows.Forms.Label TuSo2;
        private System.Windows.Forms.Label PS2;
        private System.Windows.Forms.TextBox txttu1;
        private System.Windows.Forms.TextBox txtmau1;
        private System.Windows.Forms.TextBox txttu2;
        private System.Windows.Forms.TextBox txtmau2;
        private System.Windows.Forms.Button BtnMinus;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnTimes;
        private System.Windows.Forms.Button BtnDivided;

        

        private System.Windows.Forms.TextBox txtkqtu;
        private System.Windows.Forms.TextBox txtkqmau;
        private System.Windows.Forms.Label KqMau;
        private System.Windows.Forms.Label KqTu;
        private System.Windows.Forms.Label groupKq;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

