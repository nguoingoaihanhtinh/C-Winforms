﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhanSo_TinhToan
{
    public partial class Form1 : Form
    {
        float tu1, tu2, mau1, mau2, tu, mau, k;
        public Form1()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        { }
        private void label2_Click(object sender, EventArgs e)
        { }
        private void label3_Click(object sender, EventArgs e)
        { }
        private void label8_Click(object sender, EventArgs e)
        { }
        private void textBox1_TextChanged(object sender, EventArgs e)
        { }
        private void textBox3_TextChanged(object sender, EventArgs e)
        { }
        private void textBox4_TextChanged(object sender, EventArgs e)
        { }



        private void BtnOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void BtnContinue_Click(object sender, EventArgs e)
        {
            TuSo1.ResetText();
            MauSo1.ResetText();
            MauSo1.ResetText();
            MauSo2.ResetText();
            KqTu.ResetText();
            KqMau.ResetText();
            groupKq.Text = "Ket qua";
            tu = 0; tu1 = 0; tu2 = 0;
            mau = 0; mau1 = 0; mau2 = 0;
            k = 0;
        }
        private void grBox_PhepTinh(object sender, EventArgs e)
        {
            tu1 = float.Parse(txttu1.Text);
            tu2 = float.Parse(txttu2.Text);
            mau1 = float.Parse(txtmau1.Text);
            mau2 = float.Parse(txtmau2.Text);
        }
        public static float USCLN(float a, float b)
        {
            if (b == 0)
            {
                return a;
            }
            else return USCLN(b, a % b);
        }
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            tu1 = float.Parse(txttu1.Text);
            tu2 = float.Parse(txttu2.Text);
            mau1 = float.Parse(txtmau1.Text);
            mau2 = float.Parse(txtmau2.Text);
            this.groupKq.Text = "Ket qua cong: ";
            tu = (tu1 * mau2) + (tu2 * mau1);
            mau = mau1 * mau2;
            k = USCLN(tu, mau);
            txtkqtu.Text = Convert.ToString(tu / k);
            txtkqmau.Text = Convert.ToString(mau / k);
        }
        private void BtnMinus_Click(object sender, EventArgs e)
        {
            tu1 = float.Parse(txttu1.Text);
            tu2 = float.Parse(txttu2.Text);
            mau1 = float.Parse(txtmau1.Text);
            mau2 = float.Parse(txtmau2.Text);
            this.groupKq.Text = "Ket qua tru: ";
            tu = (tu1 * mau2) - (tu2 * mau1);
            mau = mau1 * mau2;
            k = USCLN(tu, mau);
            txtkqtu.Text = Convert.ToString(tu / k);
            txtkqmau.Text = Convert.ToString(mau / k);
        }
        private void BtnTimes_Click(object sender, EventArgs e)
        {
            tu1 = float.Parse(txttu1.Text);
            tu2 = float.Parse(txttu2.Text);
            mau1 = float.Parse(txtmau1.Text);
            mau2 = float.Parse(txtmau2.Text);
            this.groupKq.Text = "Ket qua nhan: ";
            tu = (tu1 * tu2);
            mau = mau1 * mau2;
            k = USCLN(tu, mau);
            txtkqtu.Text = Convert.ToString(tu / k);
            txtkqmau.Text = Convert.ToString(mau / k);
        }
        private void BtnDivided_Click(object sender, EventArgs e)
        {
            tu1 = float.Parse(txttu1.Text);
            tu2 = float.Parse(txttu2.Text);
            mau1 = float.Parse(txtmau1.Text);
            mau2 = float.Parse(txtmau2.Text);
            this.groupKq.Text = "Ket qua chia: ";
            tu = tu1 * mau2;
            mau = mau1 * tu2;
            k = USCLN(tu, mau);
            txtkqtu.Text = Convert.ToString(tu / k);
            txtkqmau.Text = Convert.ToString(mau / k);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}
