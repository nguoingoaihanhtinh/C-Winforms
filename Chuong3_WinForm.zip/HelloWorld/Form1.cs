﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloWorld
{
    public partial class Form1 : Form
    {
        Label title;

        public Form1()
        {
            this.Text = "hello world";
            this.Size = new Size(400, 200);
            title = new Label();
            title.Text = "hello world";
            title.Location = new Point(50, 50);
            this.Controls.Add(title);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Application.Run(new Form1());
        }
    
    }
}
