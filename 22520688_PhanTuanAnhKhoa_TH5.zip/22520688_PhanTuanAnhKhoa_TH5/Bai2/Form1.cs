﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai2
{
    public partial class BallGame : Form
    {
        private Timer gameTimer;
        private PictureBox paddle;
        private PictureBox ball;
        private int ballSpeedX = 5;
        private int ballSpeedY = 5;

        public BallGame()
        {
            InitializeComponent();
            InitializeGame();
        }
        private void InitializeGame()
        {
            // Cài đặt cửa sổ trò chơi
            Text = "Ball Game";
            Size = new Size(800, 600);
            CenterToScreen();
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            // Tạo bảng trò chơi
            CreatePaddle();
            CreateBall();
            MouseMove += BallGame_MouseMove;


            // Tạo timer để cập nhật trạng thái trò chơi
            gameTimer = new Timer();
            gameTimer.Interval = 16; // Khoảng 60 fps
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();
        }
        private void CreatePaddle()
        {
            paddle = new PictureBox();
            paddle.BackColor = Color.Blue;
            paddle.Size = new Size(100, 20);
            paddle.Location = new Point((ClientSize.Width - paddle.Width) / 2, ClientSize.Height - 50);

            Controls.Add(paddle);
        }

        private void CreateBall()
        {
            ball = new PictureBox();
            ball.BackColor = Color.Red;
            ball.Size = new Size(20, 20);
            ball.Location = new Point(ClientSize.Width / 2, ClientSize.Height / 8);

            Controls.Add(ball);
        }
        private void GameTimer_Tick(object sender, EventArgs e)
        {
            ball.Left += ballSpeedX;
            ball.Top += ballSpeedY;

           
            if (ball.Left <= 0 || ball.Right >= ClientSize.Width)
            {
                ballSpeedX = -ballSpeedX;
            }

            if (ball.Top <= 0)
            {
                ballSpeedY = -ballSpeedY;  
            }

           
            if (ball.Bottom >= ClientSize.Height)
            {
                gameTimer.Stop();
                MessageBox.Show("Game Over!");
                Close();
            }

      
            if (ball.Bounds.IntersectsWith(new Rectangle(paddle.Left, paddle.Top, paddle.Width, paddle.Height)))
            {
                ballSpeedY = -ballSpeedY;
            }
        }
        private void BallGame_Load(object sender, EventArgs e)
        {
          
        }

        private void BallGame_MouseMove(object sender, MouseEventArgs e)
        {
            // Di chuyển thanh trượt theo vị trí chuột
            paddle.Left = e.X - (paddle.Width / 2);

            // Giới hạn thanh trượt không vượt quá biên cửa sổ
            if (paddle.Left < 0)
                paddle.Left = 0;
            if (paddle.Right > ClientSize.Width)
                paddle.Left = ClientSize.Width - paddle.Width;
        }
    }
}

