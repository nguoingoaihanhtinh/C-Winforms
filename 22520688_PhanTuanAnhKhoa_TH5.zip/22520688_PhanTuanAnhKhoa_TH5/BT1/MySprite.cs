﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT1
{
    class MySprite
    {
        private Bitmap[] _ListSprites;
        public Bitmap[] ListSprites
        {
            get { return _ListSprites; }
            set
            {
                _ListSprites = value;
                _nSprite = _ListSprites.Length;
                _iSprite = 0;
                _Width = _ListSprites[0].Width;
                _Height = _ListSprites[0].Height;
            }
        }
        private int _iSprite;
        public int iSprite
        {
            get { return _iSprite; }
            set { _iSprite = value; }
        }
        private int _nSprite;
        public int nSprite
        {
            get { return _nSprite; }
            set { _nSprite = value; }
        }
        private int _Width, _Height;
        public int Width
        {
            get { return _Width; }
            set { _Width = value; }
        }
        public int Height
        {
            get { return _Height; }
            set { _Height = value; }
        }
        private int _x, _y;
        public int X
        {
            get { return _x; }
            set { _x = value; }
        }
        public int Y
        {
            get { return _y; }
            set { _y = value; }
        }

        public MySprite(Bitmap[] listSprites, int x, int y)
        {
            ListSprites = listSprites;
            X = x;
            Y = y;
        }
        public void Update()
        {
            _iSprite = (_iSprite + 1) % _nSprite;
        }
        public void DrawSprite(Graphics g)
        {
            g.DrawImage(_ListSprites[_iSprite], _x, _y);
        }
    }
}
